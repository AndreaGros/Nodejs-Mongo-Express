import { Component, inject, Input } from '@angular/core';
import { CommonService } from '../services/common-service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-header-component',
  imports: [FormsModule],
  templateUrl: './header-component.html',
  styleUrl: './header-component.css',
})
export class HeaderComponent {
  public commonService = inject(CommonService)
  private router: Router = inject(Router);
  public socketStatus: string = "DISCONNECTED"
  public txtMessage: string = "In attesa di connessione"

  ngOnInit() {
    if (!this.commonService.username)
      this.router.navigate(["login"])
  }

  entra() {
    if (!this.commonService.selectedRoom) {
      alert("Perfavore inserisci una stanza")
      return
    }
    this.router.navigate(["main"])
  }
}
