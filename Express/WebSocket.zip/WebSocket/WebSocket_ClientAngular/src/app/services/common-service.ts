import { inject, Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { DataStorageService } from './data-storage-service';

@Injectable({
  providedIn: 'root',
})

export class CommonService {

  public dataStorageService: DataStorageService = inject(DataStorageService)
  public selectedRoom: string = ""
  public username: string = ""
  messages: any[] = []

  doLogin(user: any): Observable<any> {
    //pipe: quando i dati erriveranno dal server li intercetto prima di restituirli al chiamante
    //tap: legge i dati
    // facciamo chiamata POST in modo che i parametri non vengano accodati alla url rendendo il tutto più sicuro
    return this.dataStorageService.InviaRichiesta("POST", "/login", user)!.pipe(
      tap((data: any) => {
        this.username = data.username.split("@")[0]
      })
    );
  }

  doLogout() {
    return this.dataStorageService.InviaRichiesta("POST", "/logout")!
  }

  loginWithGoogle(googleToken: string): Observable<any> {
    return this.dataStorageService.InviaRichiesta("POST", "/loginWithGoogle", { googleToken })!.pipe(
      tap((data: any) => {
        this.username = data.username.split("@")[0]
      })
    );;
  }
}
