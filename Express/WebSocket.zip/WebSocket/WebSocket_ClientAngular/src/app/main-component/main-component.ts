import { Component, inject } from '@angular/core';
import { CommonService } from '../services/common-service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { io, Socket } from 'socket.io-client';
import { webSocket } from 'rxjs/webSocket';

@Component({
  selector: 'app-main-component',
  imports: [FormsModule],
  templateUrl: './main-component.html',
  styleUrl: './main-component.css',
})
export class MainComponent {

  public commonService: CommonService = inject(CommonService);
  private router: Router = inject(Router);

  socketStatus: any
  txtMessage: any;

  public wsCLient: Socket | null = null

  ngOnInit() {
    if (!this.commonService.username) {
      this.router.navigate(["login"])
      return
    }
    this.socketStatus = "Waiting for the connection"
    this.connetti()
  }

  onInvia() {
    this.wsCLient?.emit("NewMessage", this.txtMessage)
    this.txtMessage = ""
  }

  onLogout() {
    this.wsCLient?.disconnect()
    this.commonService.username = ""
    this.commonService.doLogout().subscribe({
      next: () => {
        alert("Sessione chiusa correttamente")
        this.router.navigate(["login"])
      },
      error: (err) => {
        alert("Sessione scaduta")
        this.router.navigate(["login"])
      }
    })
  }

  onEsci() {
    this.wsCLient?.disconnect()
    this.router.navigate(["header"])

  }

  imgMancante(event: any) {
    event.target!.src = "./img/default.png"
  }

  connetti() {
    const serverURL = "https://localhost:3000"
    let options = {
      transports: ["websocket"],
      upgrade: false
    }
    this.wsCLient = io(serverURL, options)
    // quando il server accetta la connessione, sul client scatta l'evento connect
    this.wsCLient.on("connect", () => {
      this.socketStatus = "CONNECTED"
      const user: any = { username: this.commonService.username, room: this.commonService.selectedRoom }
      console.log(user)
      this.wsCLient?.emit("JoinRoom", JSON.stringify(user))
    })
    this.wsCLient.on("JoinRoomCK", (data: any) => {
      if (data == "ok")
        document.title = this.commonService.username
    })

    this.wsCLient.on("NotifyMessage", (data) => {
      const message = JSON.parse(data)
      console.log(data)
      message.date = (new Date(message.date)).toLocaleDateString()
      this.commonService.messages.unshift(message)
      console.log(this.commonService.messages)
    })
  }
}
